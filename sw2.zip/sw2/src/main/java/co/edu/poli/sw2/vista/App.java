package co.edu.poli.sw2.vista;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    private static Scene scene;

      @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("droneVista"), 1280, 800);
        stage.setScene(scene);
        stage.setTitle("Gestión de Drones - Proyecto 2 Software 2");
        stage.setMinWidth(1100);
        stage.setMinHeight(650);
        stage.setMaximized(true);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(
            App.class.getResource("/sw2/co/edu/poli/sw2/vista/" + fxml + ".fxml")
        );

        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }
}